/****************************************************************/
/* Copyright (c) 2018 Jason Brewer								*/
/* New Beginnings												*/
/* Fp Parser Header												*/
/* Header file for floating point parser						*/
/****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

void argCheck (int number);
void numberCheck (int fracvalue, int expvalue, char* hexvalue);
double biasCalc (int exponent);
int fracBits (int number, int length);
int expBits (int number,  int length, int fracLength);
int signValue(int number, int length);
int bitCheck(int expbits);
void infCheck(int expBits, int fracBits, int expLength, int sign);
float mantissaCalc(int frac, int fracLength, int bitcheck);
float floatCalc (float mantissa, int exp, int bias, int sign, int bitcheck);
