/****************************************************************/
/* Copyright (c) 2018 Jason Brewer								*/
/* New Beginnings												*/
/* Fp Parser													*/
/* Takes command line arguments to return a floating point value*/
/****************************************************************/

#include "parse_header.h"
	
int main(int argc, char **argv)
{
	int fracLength, expLength, totalLength, frac, exp, bias, sign, bitcheck;//Variables used in calculations
	unsigned int hex;														//Unsigned because of pedantic
	float floatValue, mantissa;												//Float values
	char *hexvalue = argv[3];												//Used to pass string to check that it is a hex value

	//Checks arguments to make sure there are 4
	argCheck(argc);
	//Sscanf to grab values from user
	sscanf(argv[1], "%d", &fracLength);					
	sscanf(argv[2], "%d", &expLength);
	sscanf(argv[3], "%x", &hex);
	//Checks to make sure command line values are in range
	numberCheck(fracLength, expLength, hexvalue);
	//Initializing variables
	totalLength = fracLength + expLength;
	sign = signValue(hex, totalLength);
	bias = (int)biasCalc(expLength);
	frac = fracBits(hex, fracLength);
	exp = expBits(hex, totalLength, fracLength);
	//Check whether denormalized and check if it's a special case
	bitcheck = bitCheck(exp); 
	infCheck(exp, frac, expLength, sign);
	//Final Calculations
	mantissa = mantissaCalc(frac, fracLength, bitcheck);
	floatValue = floatCalc(mantissa, exp, bias, sign, bitcheck);

	//Print statement
	printf("%f\n", floatValue);

	return 0;
} 
