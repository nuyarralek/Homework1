/****************************************************************/
/* Copyright (c) 2018 Jason Brewer								*/
/* New Beginnings												*/
/* Fp Parser Functions											*/
/* Functions for Floating Point Parser							*/
/****************************************************************/

#include "parse_header.h"

//Checks command line arguments and makes sure that there are enough, exits program if false.
void argCheck (int number)
{
	if (number != 4)
	{
		printf("Please enter 3 arguments into the command line.\n");
		exit(0);
	}
}

//Checks argv inputs and ensures that they are in range, prints message and exits if they are not.
void numberCheck (int fracvalue, int expvalue, char* hexvalue)
{
	int length = strlen(hexvalue);
	char c;
	if (fracvalue < 2 || fracvalue > 10)
	{	
		printf("Illegal number of fraction bits (%d). Should be between 2 and 10\n", fracvalue);
		exit(0);
	}
	
	if (expvalue < 3 || expvalue > 5)
	{
		printf("Illegal number of exponent bits (%d). Should be between 3 and 5\n", expvalue);
		exit(0);
	}

	for (int i = 0; i < length; i++)
	{
		if (isxdigit(hexvalue[i]) == 0)
		{
			printf("Illegal value for hexadecimal input. Should be a character from 1 to F\n");
			exit(0);
		}
	}
}

//Takes an integer and performs the operation 2^(x-1) - 1 to return a bias.
double biasCalc (int exponent)
{
	return pow(2.0, exponent - 1) - 1;
}

//Takes two arguments, a number and fraction length and uses a bit mask to find the last digits.
int fracBits (int number, int length)
{
	return number & ((1 << length) - 1);
}

//Takes three arguments, a number, total length, and the fraction length and uses a bit mask to find the digits for the exponent slot.
int expBits (int number,  int length, int fracLength)
{
	return ((number & ((1 << length)-1)) >> fracLength);
}

//Takes a number argument and length argument, and returns 1 or 0 to determine sign of the float.
int signValue(int number, int length)
{
	return (number >> length) & 1;
}


//Checks to see if the expBits are all 0. Returns 1 if true.
int bitCheck(int expbits)
{
	if (expbits == 0)
	{
		return 1;
	}
	return 0;
}

//Checks to see if expBits are all 1s. Will print a statement and exit if value represents inf, -inf or NaN.
void infCheck(int expBits, int fracBits, int expLength, int sign)
{
	if (expBits == ((1 << expLength) - 1))
	{
		if (fracBits == 0)
		{
			if (sign == 1)
				printf("-inf\n");
			else
				printf("inf\n");
			exit(0);
		}
		else
			printf("NaN\n");
		exit(0);
	}
	return;
}

//Takes a fraction argument, fraction length, and a bitcheck and returns a mantissa.
float mantissaCalc(int frac, int fracLength, int bitcheck)
{
	int i = 0; int count = 0;
	float sum = 0.0;
	for (i; i < fracLength + 1; i++)
	{
		unsigned int check = 1 << (fracLength - i);
		if (frac & check)
			sum = sum + 1/(pow(2, i));
	}
	if (bitcheck == 1)
		return sum;
	return sum + 1;
}
//Takes mantissa, exponent value, bias and sign value, and then calculates the float value.
float floatCalc (float mantissa, int exp, int bias, int sign, int bitcheck)
{
	int exponent;
	int signvalue = 1;
	if (bitcheck == 1)
	{
		exponent = 1 - bias;
	}
	else
		exponent = exp - bias;
	if (sign == 1)
		signvalue = -1;
	return (signvalue * (mantissa * (pow(2, exponent))));
}

